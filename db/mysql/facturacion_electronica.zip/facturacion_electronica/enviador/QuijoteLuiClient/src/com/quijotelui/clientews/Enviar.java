package com.quijotelui.clientews;

import com.quijotelui.ws.util.ArchivoUtils;
import com.quijotelui.ws.util.EnvioComprobantesWs;
import ec.gob.sri.comprobantes.ws.RespuestaSolicitud;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.ws.WebServiceException;

public class Enviar {

    String archivoFirmado;
    String destinoEnviado;
    String destinoRechazado;
    String direccionWebService;

    public Enviar(String archivoFirmado, String destinoEnviado, String destinoRechazado, String direccionWebService) {
        this.archivoFirmado = archivoFirmado;
        this.destinoEnviado = destinoEnviado;
        this.destinoRechazado = destinoRechazado;
        /*
        *Web Service de Pruebas
        *Recepción
        *https://celcer.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline?wsdl
        *
        *Autorización
        *https://celcer.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl
         */
        this.direccionWebService = direccionWebService;
    }

    public RespuestaSolicitud executeEnviar() {

        RespuestaSolicitud respuestaSolicitudEnvio = new RespuestaSolicitud();

        try {

            File archivoXMLFirmadoFile = new File(this.archivoFirmado);
            String nombreArchivo = archivoXMLFirmadoFile.getName();
            byte[] archivoXMLFirmadoByte = ArchivoUtils.archivoToByte(archivoXMLFirmadoFile);

            respuestaSolicitudEnvio = EnvioComprobantesWs.obtenerRespuestaEnvio(archivoXMLFirmadoFile, this.direccionWebService);
            ArchivoUtils.validarRespuestaEnvio(respuestaSolicitudEnvio, archivoXMLFirmadoByte, nombreArchivo, this.destinoEnviado, this.destinoRechazado);
             //System.out.println(0);
             //System.out.println(respuestaSolicitudEnvio.getEstado() + " " + "El comprobante fue enviado, está pendiente de autorización1");
            return respuestaSolicitudEnvio;

        } catch (IOException | WebServiceException ex) {
            Logger.getLogger(Enviar.class.getName()).log(Level.SEVERE, null, ex);
            RespuestaSolicitud respuestaError = new RespuestaSolicitud();
            System.out.println(2);
            //respuestaError.setEstado("Fallo en la conexión con el web service del SRI");
            
            return respuestaError;
        }
    }

}
