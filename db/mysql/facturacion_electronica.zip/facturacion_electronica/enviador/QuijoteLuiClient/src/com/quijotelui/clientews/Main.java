package com.quijotelui.clientews;

/**
 *
 * @author jorgequiguango
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        envia(args[0], args[1], args[2], args[3], args[4],args[5],args[6],args[7],args[8]);
    }

    static void envia(String path_comprobante_firmado, String comprobante_firmado, String path_comprobantes_enviados, String path_comprobantes_rechazados, String path_autorizados, String path_no_autorizados,String ws_rececion,String ws_autorizacion,String clave_acceso) {
        Enviar enviar = new Enviar(path_comprobante_firmado + comprobante_firmado, path_comprobantes_enviados, path_comprobantes_rechazados,ws_rececion);
        enviar.executeEnviar();

        /*Comprobar comprovar = new Comprobar(path_autorizados,path_no_autorizados,ws_autorizacion);
        comprovar.executeComprobar(clave_acceso);*/
    }        
}
