package com.quijotelui.firmador;

import java.io.File;
import java.util.Scanner;
import java.io.Console;

/**
 *
 * @author jorgequiguango
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        XAdESBESSignature xadesBesFirma = new XAdESBESSignature();
        File archivo = new File(args[0]+args[1]); /* Donde lee*/
        String urlOutArchivo = args[2];          /* Donde guarda*/
        String PKCS12_RESOURCE = args[3];       /* Ruta de la firma digital*/
        String PKCS12_PASSWORD =args[4];       /*Contrasena certificado*/
        String nombreP12 = args[5];           /* Nombre Certificado*/
        PKCS12_RESOURCE = PKCS12_RESOURCE + File.separatorChar + nombreP12;

        xadesBesFirma.firmar(archivo.getAbsolutePath(), archivo.getName(),
                urlOutArchivo, PKCS12_RESOURCE, PKCS12_PASSWORD);
    }
}
